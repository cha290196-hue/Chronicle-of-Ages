import test from 'node:test';
import assert from 'node:assert/strict';
import {BASELINE,validYear,FIRST_YEAR,LAST_YEAR,displayYear} from '../src/data.js';
import {extractJSON,safeConfig,validEndpoint,sanitizeWorldline,inheritedState,worldEvents,worldFacts,simulate,configured} from '../src/core.js';

const cfg={provider:'custom',endpoint:'https://example.com/v1/chat/completions',model:'mock',key:'test'};

test('historical archive is sorted and stays within a strict non-zero-year period',()=>{
 assert.ok(BASELINE.length>=35);assert.equal(BASELINE[0].year,FIRST_YEAR);
 for(const [i,event] of BASELINE.entries()){assert.ok(validYear(event.year));if(i)assert.ok(event.year>=BASELINE[i-1].year);assert.ok(event.en&&event.zh)}
 assert.ok(!validYear(0));assert.ok(!validYear(-3201));assert.ok(!validYear(2027));assert.ok(validYear(2026));
 assert.match(displayYear(-1453),/BCE/);assert.match(displayYear(1234,'zh'),/公元/);
});
test('JSON extraction handles fenced content and rejects malformed data',()=>{
 assert.deepEqual(extractJSON('```json\n{"a":1}\n```'),{a:1});assert.deepEqual(extractJSON('prefix {"a":2} suffix'),{a:2});assert.throws(()=>extractJSON('broken'),/INVALID_JSON/);
});
test('endpoint validator rejects insecure remote origins',()=>{
 assert.ok(validEndpoint('https://api.openai.com/v1/chat/completions'));assert.ok(validEndpoint('http://localhost:8000/v1/chat/completions'));assert.equal(validEndpoint('http://example.com/v1/chat/completions'),false);assert.equal(validEndpoint('javascript:alert(1)'),false);
});
test('validates imported worldline shape',()=>{
 assert.equal(sanitizeWorldline({id:'x',anchorYear:2000,events:[]}),null);
 assert.ok(sanitizeWorldline({id:'a',anchorYear:1900,events:[{id:'e',year:1914,en:'A'}],facts:[],inherited:{events:[],facts:[]}}));
 assert.equal(configured(safeConfig({})),false);
});
test('branch-local knowledge snapshot preserves pre-fork history only',()=>{
 const parent={id:'b1',parentId:null,anchorYear:1200,prompt:'change',titleEn:'One',events:[{id:'e1',year:1220,en:'A'},{id:'e2',year:1500,en:'B'}],facts:[{id:'f1',firstYear:1250,nameEn:'A'},{id:'f2',firstYear:1550,nameEn:'B'}],inherited:{events:[],facts:[]}};
 const snapshot=inheritedState([parent],'b1',1300);
 assert.deepEqual(snapshot.events.map(x=>x.id),['e1']);assert.deepEqual(snapshot.facts.map(x=>x.id),['f1']);
});
test('DeepSeek one-click preset uses current official chat endpoint and never changes image configuration',async()=>{
 const {withTextPreset,PROVIDERS,imageConfigured}=await import('../src/core.js');
 const source=safeConfig({textEnabled:false,imageEnabled:true,imageProvider:'custom',imageEndpoint:'https://image.example.com/v1/images/generations',imageModel:'graphic-x',imageKey:'img-only-secret'});
 const next=withTextPreset(source,'deepseek');
 assert.equal(PROVIDERS.deepseek.model,'deepseek-flash');
 assert.equal(next.endpoint,'https://api.deepseek.com/chat/completions');
 assert.equal(next.model,'deepseek-flash');
 assert.equal(next.textEnabled,true);
 assert.equal(next.imageEndpoint,source.imageEndpoint);
 assert.equal(next.imageKey,'img-only-secret');
 assert.ok(imageConfigured(next));
 assert.equal(withTextPreset(next,'deepseek','deepseek-v4-pro').model,'deepseek-flash');
});

test('text-only mode ignores missing image API, and image-only keeps its own secret',async()=>{
 const {imageConfigured,generateImage}=await import('../src/core.js');
 const text=safeConfig({...cfg,textEnabled:true,imageEnabled:false,imageModel:'',imageKey:''});
 assert.ok(configured(text));assert.ok(!imageConfigured(text));
 const image=safeConfig({provider:'deepseek',endpoint:'',model:'',key:'',textEnabled:false,imageEnabled:true,imageProvider:'custom',imageEndpoint:'https://example.com/v1/images/generations',imageModel:'image-model',imageKey:'image-only-key'});
 assert.ok(!configured(image));assert.ok(imageConfigured(image));
 const prior=globalThis.fetch;let usedHeader='',usedModel='';
 globalThis.fetch=async(_url,opts)=>{usedHeader=opts.headers.authorization;usedModel=JSON.parse(opts.body).model;return {ok:true,json:async()=>({data:[{b64_json:'ZmFrZQ=='}]})}};
 try{const out=await generateImage({prompt:'A bridge',branch:null,config:image});assert.equal(usedHeader,'Bearer image-only-key');assert.equal(usedModel,'image-model');assert.match(out.data,/^data:image\/png;base64,/)}finally{globalThis.fetch=prior}
});

test('DeepSeek structured requests use JSON output and disable thinking to preserve token budget',async()=>{
 const {callChat}=await import('../src/core.js');const prior=globalThis.fetch;let body;
 globalThis.fetch=async(_url,opts)=>{body=JSON.parse(opts.body);return {ok:true,json:async()=>({choices:[{message:{content:'{"ok":true}'}}]})}};
 try{const config=safeConfig({provider:'deepseek',endpoint:'https://api.deepseek.com/chat/completions',model:'deepseek-flash',key:'sample'});const result=await callChat(config,[{role:'user',content:'JSON only'}],{json:true});assert.deepEqual(result,{ok:true});assert.deepEqual(body.thinking,{type:'disabled'});assert.deepEqual(body.response_format,{type:'json_object'});}finally{globalThis.fetch=prior}
});

test('old archive dates migrate and impossible gradual archives are rejected',()=>{
 const old={id:'old',anchorYear:123,events:[],facts:[],inherited:{events:[],facts:[]}};
 const out=sanitizeWorldline(old);assert.equal(out.timeMode,'point');assert.equal(out.transitionEndYear,123);
 assert.equal(sanitizeWorldline({...old,timeMode:'gradual',transitionEndYear:90}),null);
});
test('grandchild inherits history only before each fork',()=>{
 const a={id:'a',parentId:null,anchorYear:123,events:[{id:'one',year:124},{id:'later',year:1700}],facts:[]};
 const b={id:'b',parentId:'a',anchorYear:800,events:[{id:'two',year:801}],facts:[]};
 assert.deepEqual(inheritedState([a,b],'b',1000).events.map(x=>x.id).sort(),['one','two']);
});

test('retired saved DeepSeek text profiles migrate to Flash before a core request',async()=>{
 const {callChat}=await import('../src/core.js');const original=globalThis.fetch;let model;
 globalThis.fetch=async(_,o)=>{model=JSON.parse(o.body).model;return {ok:true,json:async()=>({choices:[{message:{content:'answer'}}]})}};
 try{await callChat({provider:'deepseek',model:'deepseek-v4-pro',endpoint:'https://api.deepseek.com/chat/completions',key:'test-only'},[],{maxTokens:100});assert.equal(model,'deepseek-flash');}finally{globalThis.fetch=original;}
});
